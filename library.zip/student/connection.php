<?php
$db = mysqli_connect("localhost","root","","library");
if ($db) {
    // echo"Done";
} else {
    // echo "Error";
}
?>